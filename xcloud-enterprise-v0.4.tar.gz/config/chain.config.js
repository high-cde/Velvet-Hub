// Evidence Chain industriale xCLOUD-by-zdos.
// Nessun wallet, token, valuta, mining, RPC pubblico o transazione blockchain.
export const CHAIN_CONFIG = {
  enabled: true,
  mode: "industrial-provenance",
  appendOnly: true,
  publicWrites: false,
  externalLedger: false,
  digest: "sha256",
  eventTypes: [
    "attendance.recorded",
    "checklist.completed",
    "inspection.logged",
    "nonconformity.opened",
    "nonconformity.closed",
    "document.versioned",
    "work_order.approved",
    "report.issued"
  ],
  retention: {
    defaultDays: 2555,
    legalHoldSupported: true
  }
};
