# Deploy xCLOUD Enterprise v0.2

## Principio

Il deploy aggiorna soltanto il webroot statico di xCLOUD. Non modifica War Room, core-01, PostgreSQL, Redis, Certbot o gli altri virtual host. Prima di ogni modifica viene creato uno snapshot locale con permessi restrittivi.

## Verifica release

```bash
cd /srv/zdos/src/xCLOUD-by-zdos
printf 'commit='; git rev-parse --short HEAD
sha256sum index.html
```

La release deve essere verificata fuori dal server prima di essere copiata nel webroot. Non eseguire `update.sh`.

## Deploy consigliato

```bash
set -Eeuo pipefail
SRC=/srv/zdos/src/xCLOUD-by-zdos
WEB=/var/www/xcloud.x-zdos.it/public
STAMP=$(date +%Y%m%d-%H%M%S)
BACKUP=/root/zdos-xcloud-release-backup-$STAMP
RELEASE=/srv/zdos/releases/xcloud-$STAMP

sudo install -d -m 0700 "$BACKUP" "$RELEASE"
sudo cp -a "$WEB" "$BACKUP/webroot-before" 2>/dev/null || true
sudo cp -a "$SRC/index.html" "$RELEASE/index.html"
sudo chown -R root:root "$RELEASE"
sudo chmod 0755 "$RELEASE"
sudo chmod 0644 "$RELEASE/index.html"

sudo rsync -a --delete "$RELEASE/" "$WEB/"
sudo chown -R www-data:www-data "$WEB"
sudo find "$WEB" -type d -exec chmod 0755 {} +
sudo find "$WEB" -type f -exec chmod 0644 {} +
sudo nginx -t
sudo systemctl reload nginx

curl -fsSIL --max-time 20 https://xcloud.x-zdos.it/ | head -12
printf 'BACKUP=%s\nRELEASE=%s\n' "$BACKUP" "$RELEASE"
```

## Rollback

```bash
set -Eeuo pipefail
BACKUP=/root/zdos-xcloud-release-backup-YYYYMMDD-HHMMSS
WEB=/var/www/xcloud.x-zdos.it/public
sudo rm -rf "$WEB"
sudo cp -a "$BACKUP/webroot-before" "$WEB"
sudo chown -R www-data:www-data "$WEB"
sudo nginx -t
sudo systemctl reload nginx
```

Sostituire il timestamp con il valore stampato dal deploy. Se il test Nginx fallisce, non ricaricare il servizio e ripristinare il backup della release, non il certificato.
