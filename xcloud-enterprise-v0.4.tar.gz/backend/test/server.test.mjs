import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';

const port = 3325;
let child;

async function waitForServer() {
  child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('..', import.meta.url), env: { ...process.env, DATABASE_URL: '', XCLOUD_PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'] });
  for (let i = 0; i < 30; i += 1) {
    try { await fetch(`http://127.0.0.1:${port}/api/health`); return; } catch { await new Promise((resolve) => setTimeout(resolve, 100)); }
  }
  throw new Error('backend did not start');
}

test.before(waitForServer);
test.after(() => child?.kill('SIGTERM'));

test('health is explicit when database is not configured', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/health`);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.status, 'ok');
  assert.equal(body.database.status, 'not-configured');
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.equal(response.headers.get('content-security-policy'), "default-src 'none'; frame-ancestors 'none'");
});

test('module registry returns declared modules without data', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/modules`);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.modules.length, 15);
  assert.ok(body.modules.every((module) => module.status === 'declared' && module.backend === 'policy-required'));
  assert.ok(body.modules.some((module) => module.id === 'workforce'));
  assert.ok(body.modules.some((module) => module.id === 'properties'));
  assert.ok(body.modules.some((module) => module.id === 'maps'));
  assert.ok(body.modules.some((module) => module.id === 'evidence'));
});

test('write methods are rejected', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/audit`, { method: 'POST' });
  assert.equal(response.status, 405);
});

test('cleaning, workforce, maps and evidence contracts are explicit', async () => {
  const endpoints = ['/api/cleaning/contract', '/api/workforce/policy', '/api/maps/policy', '/api/evidence/policy'];
  const bodies = await Promise.all(endpoints.map(async (endpoint) => {
    const response = await fetch(`http://127.0.0.1:${port}${endpoint}`);
    assert.equal(response.status, 200);
    return response.json();
  }));
  assert.equal(bodies[0].schema, 'xcloud.cleaning.contract.v1');
  assert.deepEqual(bodies[1].attendanceModes, ['online', 'offline']);
  assert.equal(bodies[2].modes.includes('offline'), true);
  assert.equal(bodies[3].cryptoAssets, false);
  assert.equal(bodies[3].appendOnly, true);
});
