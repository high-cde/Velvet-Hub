import http from 'node:http';
import crypto from 'node:crypto';
import pg from 'pg';

const { Pool } = pg;
const HOST = process.env.XCLOUD_HOST ?? '127.0.0.1';
const PORT = Number(process.env.XCLOUD_PORT ?? 3025);
const DATABASE_URL = process.env.DATABASE_URL ?? '';
const VERSION = process.env.XCLOUD_VERSION ?? '0.4.0';

const modules = [
  ['crm', 'CRM & Accounts', 'CRM.READ'],
  ['projects', 'Projects & Tasks', 'PROJECTS.READ'],
  ['documents', 'Documents', 'DOCS.READ'],
  ['inventory', 'Inventory', 'INVENTORY.READ'],
  ['billing', 'Billing', 'BILLING.READ'],
  ['reports', 'Reports', 'REPORTS.READ'],
  ['integrations', 'Integrations', 'INTEGRATIONS.READ'],
  ['audit', 'Audit & Evidence', 'AUDIT.READ'],
  ['admin', 'Administration', 'ADMIN.READ'],
  ['automations', 'Automations', 'AUTOMATIONS.READ'],
  ['workforce', 'Workforce & Timbrature', 'WORKFORCE.READ'],
  ['properties', 'Clienti & Condomini', 'PROPERTIES.READ'],
  ['fieldops', 'Field Operations', 'FIELDOPS.READ'],
  ['maps', 'Maps Online / Offline', 'MAPS.READ'],
  ['evidence', 'Evidence Chain', 'EVIDENCE.READ']
].map(([id, name, permission]) => ({ id, name, permission, status: 'declared', backend: 'policy-required' }));

const pool = DATABASE_URL ? new Pool({ connectionString: DATABASE_URL, max: 5, connectionTimeoutMillis: 2000, idleTimeoutMillis: 10000 }) : null;

function json(res, status, body, requestId) {
  const payload = JSON.stringify(body);
  res.writeHead(status, {
    'content-type': 'application/json; charset=utf-8',
    'content-length': Buffer.byteLength(payload),
    'cache-control': 'no-store',
    'x-content-type-options': 'nosniff',
    'x-frame-options': 'DENY',
    'referrer-policy': 'no-referrer',
    'content-security-policy': "default-src 'none'; frame-ancestors 'none'",
    'x-request-id': requestId
  });
  res.end(payload);
}

async function databaseState() {
  if (!pool) return { configured: false, status: 'not-configured' };
  try {
    await pool.query({ text: 'select 1 as ok', query_timeout: 1500 });
    return { configured: true, status: 'connected' };
  } catch {
    return { configured: true, status: 'unavailable' };
  }
}

const contracts = {
  cleaning: {
    schema: 'xcloud.cleaning.contract.v1',
    status: 'policy-required',
    scopes: ['organizations', 'customers', 'employers', 'properties', 'spaces', 'contracts', 'work_orders', 'checklists', 'nonconformities']
  },
  workforce: {
    schema: 'xcloud.workforce.contract.v1',
    status: 'policy-required',
    attendanceModes: ['online', 'offline'],
    events: ['clock_in', 'break_start', 'break_end', 'clock_out', 'correction'],
    location: { continuousTracking: false, consentRequired: true, precisionOptional: true },
    sync: { idempotencyRequired: true, conflictPolicy: 'never-silent-overwrite' }
  },
  maps: {
    schema: 'xcloud.maps.contract.v1',
    status: 'provider-required',
    modes: ['online', 'offline'],
    offlinePackageStates: ['current', 'stale', 'revoked'],
    geofencing: { optional: true, continuousEmployeeTracking: false }
  },
  evidence: {
    schema: 'xcloud.evidence.contract.v1',
    status: 'industrial-provenance',
    digest: 'sha256',
    appendOnly: true,
    externalLedger: false,
    cryptoAssets: false,
    eventTypes: ['attendance.recorded', 'checklist.completed', 'inspection.logged', 'nonconformity.opened', 'nonconformity.closed', 'document.versioned', 'work_order.approved', 'report.issued']
  }
};

const server = http.createServer(async (req, res) => {
  const requestId = req.headers['x-request-id']?.toString().slice(0, 96) || crypto.randomUUID();
  if (req.method !== 'GET') return json(res, 405, { error: 'method_not_allowed', request_id: requestId }, requestId);
  const url = new URL(req.url ?? '/', `http://${req.headers.host ?? 'localhost'}`);
  if (url.pathname === '/api/health') {
    const database = await databaseState();
    return json(res, 200, { schema: 'xcloud.health.v1', status: database.status === 'connected' || !database.configured ? 'ok' : 'degraded', service: 'xcloud-enterprise-backend', version: VERSION, database, request_id: requestId }, requestId);
  }
  if (url.pathname === '/api/modules') return json(res, 200, { schema: 'xcloud.modules.v1', modules, request_id: requestId }, requestId);
  if (url.pathname === '/api/audit') return json(res, 200, { schema: 'xcloud.audit.v1', status: 'backend-required', events: [], request_id: requestId }, requestId);
  if (url.pathname === '/api/cleaning/contract') return json(res, 200, { ...contracts.cleaning, request_id: requestId }, requestId);
  if (url.pathname === '/api/workforce/policy') return json(res, 200, { ...contracts.workforce, request_id: requestId }, requestId);
  if (url.pathname === '/api/maps/policy') return json(res, 200, { ...contracts.maps, request_id: requestId }, requestId);
  if (url.pathname === '/api/evidence/policy') return json(res, 200, { ...contracts.evidence, request_id: requestId }, requestId);
  return json(res, 404, { error: 'not_found', request_id: requestId }, requestId);
});

server.listen(PORT, HOST, () => console.log(JSON.stringify({ service: 'xcloud-enterprise-backend', host: HOST, port: PORT, version: VERSION, database_configured: Boolean(DATABASE_URL) })));

function shutdown(signal) {
  server.close(async () => { if (pool) await pool.end().catch(() => {}); process.exit(0); });
  setTimeout(() => process.exit(1), 5000).unref();
  console.warn(JSON.stringify({ event: 'shutdown_requested', signal }));
}
process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));
