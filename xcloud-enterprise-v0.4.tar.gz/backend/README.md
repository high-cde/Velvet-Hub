# xCLOUD Enterprise backend

Questo servizio è il primo boundary server-side della piattaforma. Espone soltanto health, registry dei moduli e audit read-only; si lega a `127.0.0.1` e non deve essere pubblicato direttamente su Internet.

## Stato

Il servizio è un foundation layer, non ancora un ERP completo. Le route CRUD, autenticazione, multi-tenancy applicativa e integrazioni write-capable richiedono ulteriori tranche con test e policy dedicate.

## Variabili

```text
XCLOUD_HOST=127.0.0.1
XCLOUD_PORT=3025
XCLOUD_VERSION=0.3.0
DATABASE_URL=postgresql://...
```

`DATABASE_URL` deve essere conservata soltanto in `/etc/zdos/xcloud.env` con permessi `0600`, proprietario root e gruppo del servizio. Non deve entrare in Git, nel webroot o nel browser.

## API iniziali

| Route | Metodo | Stato |
|---|---|---|
| `/api/health` | GET | Health shell e PostgreSQL, senza segreti |
| `/api/modules` | GET | Registry dichiarativo dei 10 moduli |
| `/api/audit` | GET | Contratto read-only; lista vuota finché non esiste ingest verificato |

Il backend rifiuta i metodi diversi da `GET` e applica `no-store`, CSP restrittiva, `X-Frame-Options: DENY`, `nosniff` e request id.

## Database

Applicare `migrations/001_core.sql` soltanto a un database xCLOUD dedicato, dopo aver creato un ruolo applicativo separato. Non usare il database della War Room e non assegnare al servizio privilegi di superuser.
