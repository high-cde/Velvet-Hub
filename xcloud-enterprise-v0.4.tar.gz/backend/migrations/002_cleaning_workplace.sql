BEGIN;

CREATE TABLE IF NOT EXISTS xcloud_organizations (
  id TEXT PRIMARY KEY,
  kind TEXT NOT NULL CHECK (kind IN ('cleaning_company','customer','employer','condominium')),
  legal_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended','archived')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS xcloud_users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL,
  display_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'invited' CHECK (status IN ('invited','active','suspended','revoked')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS xcloud_users_email_lower_idx ON xcloud_users (lower(email));

CREATE TABLE IF NOT EXISTS xcloud_user_roles (
  user_id TEXT NOT NULL REFERENCES xcloud_users(id) ON DELETE CASCADE,
  organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id) ON DELETE CASCADE,
  role TEXT NOT NULL CHECK (role IN ('platform_admin','organization_owner','operations_manager','site_supervisor','employee','customer_contact','employer_contact','auditor')),
  scope JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, organization_id, role)
);

CREATE TABLE IF NOT EXISTS xcloud_properties (
  id TEXT PRIMARY KEY,
  owner_organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id),
  customer_organization_id TEXT REFERENCES xcloud_organizations(id),
  property_kind TEXT NOT NULL CHECK (property_kind IN ('condominium','office','retail','industrial','healthcare','education','public')),
  name TEXT NOT NULL,
  address_line TEXT,
  city TEXT,
  country_code CHAR(2),
  latitude NUMERIC(9,6),
  longitude NUMERIC(9,6),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','paused','archived')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS xcloud_spaces (
  id TEXT PRIMARY KEY,
  property_id TEXT NOT NULL REFERENCES xcloud_properties(id) ON DELETE CASCADE,
  parent_id TEXT REFERENCES xcloud_spaces(id),
  space_kind TEXT NOT NULL CHECK (space_kind IN ('building','floor','area','room','external_area')),
  name TEXT NOT NULL,
  service_profile JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS xcloud_work_orders (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id),
  property_id TEXT NOT NULL REFERENCES xcloud_properties(id),
  title TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'planned' CHECK (status IN ('planned','assigned','in_progress','blocked','completed','approved','cancelled')),
  scheduled_start TIMESTAMPTZ,
  scheduled_end TIMESTAMPTZ,
  assigned_team JSONB NOT NULL DEFAULT '[]'::jsonb,
  service_plan JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS xcloud_attendance_events (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id),
  user_id TEXT NOT NULL REFERENCES xcloud_users(id),
  work_order_id TEXT REFERENCES xcloud_work_orders(id),
  event_type TEXT NOT NULL CHECK (event_type IN ('clock_in','break_start','break_end','clock_out','correction')),
  occurred_at TIMESTAMPTZ NOT NULL,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  capture_mode TEXT NOT NULL CHECK (capture_mode IN ('online','offline')),
  idempotency_key TEXT NOT NULL,
  location_precision_m NUMERIC(8,2),
  location_consent BOOLEAN NOT NULL DEFAULT false,
  correction_reason TEXT,
  approval_status TEXT NOT NULL DEFAULT 'pending' CHECK (approval_status IN ('pending','approved','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (organization_id, idempotency_key)
);

CREATE TABLE IF NOT EXISTS xcloud_map_packages (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id),
  property_id TEXT NOT NULL REFERENCES xcloud_properties(id) ON DELETE CASCADE,
  version TEXT NOT NULL,
  package_uri TEXT NOT NULL,
  captured_at TIMESTAMPTZ NOT NULL,
  expires_at TIMESTAMPTZ,
  status TEXT NOT NULL CHECK (status IN ('current','stale','revoked')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (property_id, version)
);

CREATE TABLE IF NOT EXISTS xcloud_evidence_chain (
  event_id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES xcloud_organizations(id),
  event_type TEXT NOT NULL,
  subject_type TEXT NOT NULL,
  subject_id TEXT NOT NULL,
  actor_id TEXT REFERENCES xcloud_users(id),
  occurred_at TIMESTAMPTZ NOT NULL,
  payload_digest CHAR(64) NOT NULL,
  previous_digest CHAR(64),
  chain_digest CHAR(64) NOT NULL,
  source TEXT NOT NULL CHECK (source IN ('web','mobile','import','system')),
  classification TEXT NOT NULL DEFAULT 'internal' CHECK (classification IN ('public','internal','confidential','restricted')),
  retention_until DATE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS xcloud_properties_customer_idx ON xcloud_properties (customer_organization_id);
CREATE INDEX IF NOT EXISTS xcloud_work_orders_property_status_idx ON xcloud_work_orders (property_id, status);
CREATE INDEX IF NOT EXISTS xcloud_attendance_user_occurred_idx ON xcloud_attendance_events (user_id, occurred_at DESC);
CREATE INDEX IF NOT EXISTS xcloud_evidence_chain_org_created_idx ON xcloud_evidence_chain (organization_id, created_at DESC);

REVOKE ALL ON TABLE xcloud_organizations, xcloud_users, xcloud_user_roles, xcloud_properties, xcloud_spaces, xcloud_work_orders, xcloud_attendance_events, xcloud_map_packages, xcloud_evidence_chain FROM PUBLIC;
COMMIT;
