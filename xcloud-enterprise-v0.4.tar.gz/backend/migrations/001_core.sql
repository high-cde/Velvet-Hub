BEGIN;

CREATE TABLE IF NOT EXISTS xcloud_audit_events (
  id BIGSERIAL PRIMARY KEY,
  tenant_id TEXT NOT NULL,
  actor_id TEXT NOT NULL,
  action TEXT NOT NULL,
  resource_type TEXT NOT NULL,
  resource_id TEXT,
  outcome TEXT NOT NULL CHECK (outcome IN ('accepted','rejected','failed')),
  correlation_id TEXT NOT NULL,
  metadata JSONB NOT NULL DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS xcloud_audit_events_tenant_created_idx
  ON xcloud_audit_events (tenant_id, created_at DESC);

CREATE INDEX IF NOT EXISTS xcloud_audit_events_correlation_idx
  ON xcloud_audit_events (correlation_id);

CREATE TABLE IF NOT EXISTS xcloud_workspaces (
  id TEXT PRIMARY KEY,
  display_name TEXT NOT NULL,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','suspended')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS xcloud_memberships (
  workspace_id TEXT NOT NULL REFERENCES xcloud_workspaces(id) ON DELETE CASCADE,
  subject_id TEXT NOT NULL,
  role TEXT NOT NULL CHECK (role IN ('owner','admin','operator','viewer')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY (workspace_id, subject_id)
);

REVOKE ALL ON TABLE xcloud_audit_events, xcloud_workspaces, xcloud_memberships FROM PUBLIC;
COMMIT;
