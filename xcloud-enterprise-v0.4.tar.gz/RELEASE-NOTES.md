# xCLOUD Enterprise v0.4 — Cleaning & Workplace

## Posizionamento

xCLOUD-by-zdos è una control plane Enterprise per imprese di pulizie, datori di lavoro, clienti, condomini e ambienti di lavoro. La release estende la shell Mission Control con un modello industriale verificabile e privo di crypto, wallet, token, valute o operazioni finanziarie sulla catena delle evidenze.

## Moduli dichiarati

CRM & Accounts, Projects & Tasks, Documents, Inventory, Billing, Reports, Integrations, Audit & Evidence, Administration, Automations, Workforce & Timbrature, Clienti & Condomini, Field Operations, Maps Online / Offline ed Evidence Chain.

## Cleaning e workplace

La piattaforma ora espone superfici per utenti e ruoli, aziende, clienti, condomini, sedi, edifici, piani, aree, ambienti, contratti, commesse, squadre, turni, checklist, materiali, segnalazioni e controlli qualità. Le timbrature sono modellate come eventi di presenza con entrata, uscita, pausa, turno, fonte, dispositivo, stato di sincronizzazione e correzione autorizzata.

## Mappe online/offline

Il modello supporta sedi e aree operative con cache locale, coda di sincronizzazione, stato online/offline, conflitti e geofencing configurabile. Nessuna posizione viene dichiarata reale finché non viene raccolta da un dispositivo autorizzato e associata a una policy privacy.

## Evidence Chain industriale

Evidence Chain è definita come registro append-only di provenienza e integrità: eventi hash-linked, soggetto, tipo di evidenza, digest, timestamp, attore, sede, retention e stato di verifica. Non è una criptovaluta, non usa wallet, non trasferisce valore e non richiede blockchain pubblica. L’eventuale ancoraggio esterno futuro dovrà essere esplicitamente autorizzato e documentato come servizio di notarizzazione, non come sistema monetario.

## Backend e sicurezza

Il backend Node.js è isolato su loopback, il database PostgreSQL è dedicato a xCLOUD e Nginx espone soltanto il proxy HTTPS autorizzato. Le scritture operative, l’autenticazione multi-tenant, le notifiche e le integrazioni esterne restano subordinate a ruoli, policy, migration, audit e test. La shell non contiene credenziali né presenta dati sintetici come dati aziendali reali.

## Verifica locale

```text
STATIC_CHECK=PASS plugins=15
BACKEND_TEST=PASS 4/4
```

## Prossima tranche

Implementare autenticazione server-side, workspace multi-tenant, inviti e revoche, ruoli dipendente/responsabile/cliente/datore di lavoro, migration cleaning/workplace `002_cleaning_workplace.sql`, API per timbrature e checklist, coda offline e audit append-only con retention configurabile. Ogni modulo dovrà avere contratto, autorizzazione, test e rollback prima dell’attivazione in produzione.
