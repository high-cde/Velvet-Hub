# xCLOUD Enterprise by ZDOS

## Obiettivo

xCLOUD deve diventare una piattaforma operativa modulare collegata all’ecosistema ZDOS, non una semplice landing page. La ricostruzione deve preservare il sito statico corrente e introdurre una shell Enterprise con moduli espandibili, ruoli, audit e integrazioni esplicite.

## Stato di partenza verificato

Il repository corrente è una build statica con `index.html`, configurazioni JavaScript locali e adapter DSN dimostrativi. Non contiene un manifest di dipendenze, un backend, migrazioni di database, autenticazione server-side o un sistema plugin reale. Le funzioni `recordOnChain`, Deploy, Logs e Chain sono simulazioni locali o placeholder e non devono essere presentate come operazioni enterprise già eseguite.

## Architettura target

| Livello | Responsabilità | Stato iniziale |
|---|---|---|
| Presentation Shell | Navigazione, command palette, workspace, responsive UI, accessibilità | Da implementare |
| Module Registry | Manifest, versioning, capability, permissions, health e lifecycle dei plugin | Da implementare |
| Core Modules | Overview, CRM, Projects, Tasks, Documents, Inventory, Billing, Reports, Settings | Da implementare per tranche |
| ZDOS Bridge | Link e API contract verso x-zdos.it, War Room e Evidence Core | Contract-first, integrazione autorizzata |
| Data Layer | PostgreSQL, tenant/workspace, audit events, migrations | Richiede backend e credenziali locali |
| Identity & Policy | Sessione server-side, ruoli, least privilege, CSRF, rate limits | Richiede backend |
| Integration Layer | DSN/chain adapter, webhook ingress/egress, email, WhatsApp, storage | Solo adapter isolati; segreti mai nel client |
| Operations | Health checks, structured logs, backups, deploy atomico, rollback | Da documentare e automatizzare |

## Moduli Enterprise

La prima tranche implementa una shell credibile con moduli reali a livello di interfaccia e stati espliciti. I moduli CRM, Projects, Tasks, Documents, Inventory, Billing, Reports, Automations, Integrations e Admin devono usare dati vuoti o locali chiaramente marcati finché non esiste un backend. Non verranno creati clienti, fatture, recensioni, KPI o eventi fittizi presentati come dati reali.

## Plugin contract

Ogni plugin dovrà avere un manifest con `id`, `name`, `version`, `category`, `entry`, `capabilities`, `permissions`, `routes`, `events`, `health` e `status`. Il registry deve rifiutare plugin con id duplicato, capability non dichiarate o permessi superiori al ruolo corrente. Un plugin disabilitato non deve caricare codice o segreti.

## Sicurezza

Il browser non deve contenere token Cloudflare, chiavi private, password, credenziali DB o chiavi RPC. Le integrazioni blockchain devono usare un relayer/server-side autorizzato e mostrare nel client solo stato e riferimenti pubblici. Le azioni sensibili devono produrre audit event con actor, action, resource, timestamp, correlation id e outcome, senza registrare segreti o dati privati.

## Collegamenti ZDOS

I collegamenti iniziali possono essere link HTTPS verso `https://x-zdos.it`, `https://zdos-sec.it`, `https://zdos-hub.it` e `https://warroom.zdos-sec.it`. Le API del War Room e dell’Evidence Core devono essere integrate soltanto dopo avere definito endpoint, autenticazione, schema delle risposte, timeout, retry e autorizzazioni. Nessun endpoint deve essere inventato o chiamato dal browser senza un contratto verificato.

## Tranche di implementazione

1. Baseline e release statica atomica con rollback.
2. Shell Enterprise e registry plugin lato client.
3. Moduli UI prioritari con empty states e import/export locale esplicito.
4. Backend Node/Express con PostgreSQL, sessioni e audit.
5. CRM, progetti, task, documenti e report persistenti.
6. Bridge ZDOS read-only verso health, node-status e attestation.
7. Integrazioni write-capable solo con policy e approvazione esplicita.
8. Test, hardening, backup, observability e deploy blue/green.

## Criterio di accettazione

Una release è Enterprise-ready solo quando build, test, sicurezza, migrazione, rollback, gestione errori e stato delle integrazioni sono verificati. Una UI ricca senza persistenza, autorizzazione e audit non deve essere descritta come piattaforma completa.

## Decisione corrente

La prima release di ricostruzione sarà una shell Enterprise statica e verificabile, compatibile con il deploy Nginx attuale. La persistenza e le integrazioni operative saranno aggiunte come secondo livello, senza introdurre credenziali nel repository o nel frontend.
