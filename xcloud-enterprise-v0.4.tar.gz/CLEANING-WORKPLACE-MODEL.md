# xCLOUD-by-zdos — Cleaning & Workplace Enterprise

## Posizionamento

xCLOUD è il pannello operativo per imprese di pulizie, facility management, condomini e datori di lavoro. Organizza persone, sedi, commesse, turni, qualità, documenti e report in una superficie unica. La **Evidence Chain** è un registro industriale di provenienza e integrità: collega eventi, checklist, documenti e verifiche tramite digest hash, timestamp, attore e relazione precedente. Non è una criptovaluta, non usa wallet, token, mining o pagamenti su blockchain.

## Organizzazione multi-tenant

| Entità | Funzione | Confine |
|---|---|---|
| Organization | Impresa titolare del workspace | Tenant principale |
| Customer | Cliente committente | Visibile solo ai tenant autorizzati |
| Employer | Datore di lavoro o referente aziendale | Accesso a personale e report autorizzati |
| Property | Condominio, sede aziendale o struttura | Appartiene a un cliente |
| Building | Edificio o corpo di fabbrica | Appartiene a una property |
| Area | Piano, zona o reparto | Appartiene a un building |
| Space | Ambiente operativo | Ha standard e checklist propri |
| Contract | Contratto/capitolato/SLA | Collega organization, customer e property |
| Work order | Commesse e attività pianificate | Eseguibile da una squadra |

## Utenze e ruoli

| Ruolo | Può vedere | Può operare | Limite principale |
|---|---|---|---|
| Platform admin | Configurazione tecnica | Policy e supporto | Nessun accesso automatico ai contenuti tenant |
| Organization owner | Tutto il proprio tenant | Utenti, contratti, policy | Non vede altri tenant |
| Operations manager | Sedi, contratti, turni, qualità | Assegnazioni, approvazioni, escalation | Scope organizzativo |
| Site supervisor | Sedi assegnate e squadre | Checklist, non conformità, chiusure | Scope per sede |
| Employee | Turni e attività assegnate | Timbrature, checklist, evidenze | Solo assegnazioni personali |
| Customer contact | Proprie sedi, SLA, report | Conferma ricezione e richieste | Solo dati condivisi |
| Employer contact | Personale e presenze autorizzate | Approvazione ore e report | Solo propria organizzazione |
| Auditor | Evidenze e audit autorizzati | Verifica e contestazione | Read-only |

## Timbrature e turni

La timbratura deve supportare entrata, uscita, pausa, ripresa, correzione motivata e approvazione. Ogni evento contiene `actor_id`, `tenant_id`, `work_order_id`, `occurred_at`, `recorded_at`, modalità `online|offline`, precisione posizione opzionale e motivo di correzione. La posizione non è obbligatoria per il funzionamento e deve essere configurabile per sito e policy; non deve essere usata per sorveglianza continua.

Gli eventi offline vengono conservati in una coda locale cifrata del dispositivo e sincronizzati con un idempotency key. Il server rifiuta duplicati, conserva l’ora dell’evento e quella di ricezione, registra conflitti e non sovrascrive silenziosamente una correzione già approvata.

## Mappe online/offline

La mappa visualizza sedi, edifici, aree e ambienti autorizzati. In modalità online usa tile e geocoding tramite provider configurato. In modalità offline mostra l’ultimo pacchetto di mappa esplicitamente scaricato, con timestamp, versione e stato `stale|current`; non dichiara dati aggiornati quando non può verificarli. Il geofencing è opzionale, perimetrale e soggetto a policy del tenant. Non viene usato per tracciare continuamente i dipendenti.

## Scheda condominio o cliente

Ogni scheda aggrega anagrafica, referente, sedi, ambienti, contratto, frequenze, standard, materiali, turni, ticket, non conformità, documenti e report. I dati sono filtrati per tenant e ruolo. Un cliente può avere più immobili; un condominio può avere più edifici e aree; un datore di lavoro può avere visibilità sulle presenze del proprio personale solo entro la policy approvata.

## Evidence Chain industriale

La catena di evidenze è append-only a livello applicativo. Ogni record include `event_id`, `tenant_id`, `event_type`, `subject_type`, `subject_id`, `actor_id`, `occurred_at`, `payload_digest`, `previous_digest`, `chain_digest`, `source`, `classification` e `retention_until`. Il payload sensibile resta nel data layer protetto; la catena conserva digest e metadati minimi per dimostrare integrità e ordine degli eventi.

Le categorie includono `attendance.recorded`, `checklist.completed`, `inspection.logged`, `nonconformity.opened`, `nonconformity.closed`, `document.versioned`, `work_order.approved` e `report.issued`. La verifica deve poter ricostruire la catena per tenant, segnalare il primo digest incoerente e produrre un export firmabile dall’organizzazione. Nessun elemento della UX deve usare terminologia finanziaria o crypto.

## KPI e report

I report devono indicare sempre periodo, fonte, filtro tenant e stato di completezza. KPI ammessi includono ore pianificate rispetto a ore approvate, attività chiuse, checklist completate, non conformità aperte/chiuse, tempi di risposta e copertura del servizio. Se il dataset non è configurato, il pannello mostra `NO DATA` o `CONFIGURATION REQUIRED`, non numeri di esempio.

## Ordine di attivazione

1. Workspace, organizzazioni, utenti, inviti e ruoli.
2. Clienti, condomini, sedi, edifici, aree e ambienti.
3. Contratti, piani di servizio, squadre, turni e work order.
4. Timbrature online/offline con sincronizzazione idempotente.
5. Checklist, evidenze, non conformità e Evidence Chain.
6. Mappe e pacchetti offline con policy di aggiornamento.
7. Documenti, report, notifiche e integrazioni autorizzate.

## Regola di sicurezza

> Se un modulo non ha tenant boundary, autorizzazione, audit, gestione errori e rollback, è una superficie di progettazione e non una funzione Enterprise attiva.
