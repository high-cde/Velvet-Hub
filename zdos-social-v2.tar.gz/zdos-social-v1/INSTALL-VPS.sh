#!/usr/bin/env bash
set -Eeuo pipefail
umask 077
[ "$(id -u)" -eq 0 ] || { echo 'ERROR_RUN_AS_ROOT'; exit 1; }
ARCHIVE=${ARCHIVE:-/root/zdos-social-v1.tar.gz}
EXPECTED_SHA=${EXPECTED_SHA:-}
APP=/opt/zdos-social
STAMP=$(date +%Y%m%d-%H%M%S)
RELEASE=$APP/releases/$STAMP
BACKUP=/root/zdos-social-before-$STAMP
WEBROOT=/var/www/zdos-hub.it/public
ENV=/etc/zdos/social.env
UNIT=/etc/systemd/system/zdos-social.service

[ -f "$ARCHIVE" ] || { echo 'ERROR_ARCHIVE_MISSING'; exit 1; }
if [ -n "$EXPECTED_SHA" ]; then
  [ "$(sha256sum "$ARCHIVE" | awk '{print $1}')" = "$EXPECTED_SHA" ] || { echo 'ERROR_ARCHIVE_SHA'; exit 1; }
fi
install -d -m 0700 "$BACKUP" "$RELEASE" /etc/zdos /var/lib/zdos-social/uploads
[ -d "$WEBROOT" ] && cp -a "$WEBROOT" "$BACKUP/hub-webroot-before" || true
[ -f /etc/nginx/sites-enabled/zdos-social.conf ] && cp -a /etc/nginx/sites-enabled/zdos-social.conf "$BACKUP/vhost-before" || true
[ -f "$ENV" ] && cp -a "$ENV" "$BACKUP/social.env-before" || true

getent group zdos-social >/dev/null || groupadd --system zdos-social
id zdos-social >/dev/null 2>&1 || useradd --system --gid zdos-social --home-dir /var/lib/zdos-social --no-create-home --shell /usr/sbin/nologin zdos-social

tar -xzf "$ARCHIVE" -C "$RELEASE" --strip-components=1
find "$RELEASE" -type d -exec chmod 0755 {} +
find "$RELEASE" -type f -exec chmod 0644 {} +
chmod 0755 "$RELEASE/INSTALL-VPS.sh"
chown -R root:root "$RELEASE"
cd "$RELEASE/backend"
npm install --omit=dev --ignore-scripts --no-audit --no-fund
node --check server.mjs

DB_PASS=''
if [ -f "$ENV" ]; then
  DB_PASS=$(sed -n 's/^DB_PASSWORD=//p' "$ENV" | head -1)
fi
if [ -z "$DB_PASS" ]; then DB_PASS=$(node -e "console.log(require('crypto').randomBytes(32).toString('base64url'))"); fi
DB_PASS_SQL=$(printf '%s' "$DB_PASS" | sed "s/'/''/g")
if sudo -u postgres psql -d postgres -X -Atc "SELECT 1 FROM pg_roles WHERE rolname='zdos_social_app'" | grep -q '^1$'; then
  sudo -u postgres psql -d postgres -X -v ON_ERROR_STOP=1 -c "ALTER ROLE zdos_social_app PASSWORD '$DB_PASS_SQL';"
else
  sudo -u postgres psql -d postgres -X -v ON_ERROR_STOP=1 -c "CREATE ROLE zdos_social_app LOGIN PASSWORD '$DB_PASS_SQL';"
fi
if ! sudo -u postgres psql -d postgres -X -Atc "SELECT 1 FROM pg_database WHERE datname='zdos_social'" | grep -q '^1$'; then
  sudo -u postgres createdb -O zdos_social_app zdos_social
fi
cat "$RELEASE/backend/migrations/001_social_core.sql" | sudo -u postgres psql -d zdos_social -X -v ON_ERROR_STOP=1 -f -
sudo -u postgres psql -d zdos_social -X -v ON_ERROR_STOP=1 <<'SQL'
GRANT USAGE ON SCHEMA public TO zdos_social_app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO zdos_social_app;
GRANT USAGE, SELECT, UPDATE ON ALL SEQUENCES IN SCHEMA public TO zdos_social_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO zdos_social_app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT, UPDATE ON SEQUENCES TO zdos_social_app;
SQL

cat > "$ENV" <<EOF
PORT=3030
DB_HOST=127.0.0.1
DB_PORT=5432
DB_NAME=zdos_social
DB_USER=zdos_social_app
DB_PASSWORD=$DB_PASS
DATA_DIR=/var/lib/zdos-social
PUBLIC_DIR=$APP/backend-public
EOF
chmod 0640 "$ENV"
chown root:zdos-social "$ENV"
rm -rf "$APP/backend-public"
install -d -m 0755 "$APP/backend-public"
cp -a "$RELEASE/public/." "$APP/backend-public/"
chown -R root:root "$APP/backend-public"
install -o root -g root -m 0644 "$RELEASE/systemd/zdos-social.service" "$UNIT"
sed -i "s#^WorkingDirectory=.*#WorkingDirectory=$RELEASE/backend#; s#^ExecStart=.*#ExecStart=/opt/node/current/bin/node $RELEASE/backend/server.mjs#" "$UNIT"
mkdir -p "$APP/releases"
ln -sfn "$RELEASE" "$APP/current"

cat > /etc/nginx/sites-available/zdos-social.conf <<'NGINX'
server {
    listen 80;
    listen [::]:80;
    server_name zdos-hub.it www.zdos-hub.it;
    return 301 https://zdos-hub.it$request_uri;
}
server {
    listen 443 ssl;
    listen [::]:443 ssl;
    server_name zdos-hub.it www.zdos-hub.it;
    ssl_certificate /etc/letsencrypt/live/zdos-origin/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/zdos-origin/privkey.pem;
    add_header Content-Security-Policy "default-src 'self'; connect-src 'self' wss:; img-src 'self' data:; style-src 'self' 'unsafe-inline'; script-src 'self' 'unsafe-inline'; base-uri 'self'; frame-ancestors 'self'" always;
    add_header Strict-Transport-Security "max-age=31536000; includeSubDomains" always;
    location / {
        proxy_pass http://127.0.0.1:3030;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto https;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_read_timeout 75s;
    }
}
NGINX
ln -sfn /etc/nginx/sites-available/zdos-social.conf /etc/nginx/sites-enabled/00-zdos-social.conf
systemctl daemon-reload
systemctl enable zdos-social.service
systemctl restart zdos-social.service
sleep 3
systemctl is-active --quiet zdos-social.service || { journalctl -u zdos-social.service -n 60 --no-pager; exit 1; }
nginx -t
systemctl reload nginx

printf '%s\n' '=== ZDOS SOCIAL INSTALL ==='
printf 'release=%s\nbackup=%s\n' "$RELEASE" "$BACKUP"
printf 'service='; systemctl is-active zdos-social.service
curl -fsS --max-time 10 http://127.0.0.1:3030/api/health
printf '\n'
printf 'ZDOS_SOCIAL_INSTALL=PASS\n'
