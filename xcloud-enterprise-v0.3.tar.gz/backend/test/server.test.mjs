import test from 'node:test';
import assert from 'node:assert/strict';
import { spawn } from 'node:child_process';

const port = 3325;
let child;

async function waitForServer() {
  child = spawn(process.execPath, ['server.mjs'], { cwd: new URL('..', import.meta.url), env: { ...process.env, DATABASE_URL: '', XCLOUD_PORT: String(port) }, stdio: ['ignore', 'pipe', 'pipe'] });
  for (let i = 0; i < 30; i += 1) {
    try { await fetch(`http://127.0.0.1:${port}/api/health`); return; } catch { await new Promise((resolve) => setTimeout(resolve, 100)); }
  }
  throw new Error('backend did not start');
}

test.before(waitForServer);
test.after(() => child?.kill('SIGTERM'));

test('health is explicit when database is not configured', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/health`);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.status, 'ok');
  assert.equal(body.database.status, 'not-configured');
  assert.equal(response.headers.get('cache-control'), 'no-store');
  assert.equal(response.headers.get('content-security-policy'), "default-src 'none'; frame-ancestors 'none'");
});

test('module registry returns declared modules without data', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/modules`);
  const body = await response.json();
  assert.equal(response.status, 200);
  assert.equal(body.modules.length, 10);
  assert.ok(body.modules.every((module) => module.status === 'declared' && module.backend === 'required'));
});

test('write methods are rejected', async () => {
  const response = await fetch(`http://127.0.0.1:${port}/api/audit`, { method: 'POST' });
  assert.equal(response.status, 405);
});
