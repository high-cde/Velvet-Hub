import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(new URL('..', import.meta.url).pathname);
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const required = [
  '<!doctype html>',
  'lang="it"',
  'xCLOUD Enterprise',
  'moduleGrid',
  'default-deny',
  'Data plane: not connected',
  'x-zdos.it',
  'warroom.zdos-sec.it'
];
for (const marker of required) {
  if (!html.includes(marker)) throw new Error(`missing marker: ${marker}`);
}
const forbidden = [/cfat_[A-Za-z0-9_-]+/i, /cfut_[A-Za-z0-9_-]+/i, /BEGIN (RSA|OPENSSH|EC) PRIVATE KEY/, /password\s*=/i, /secret\s*=/i];
for (const pattern of forbidden) {
  if (pattern.test(html)) throw new Error(`possible secret or credential pattern: ${pattern}`);
}
const pluginIds = [...html.matchAll(/id:'([a-z-]+)'/g)].map((m) => m[1]);
if (pluginIds.length !== 10) throw new Error(`expected 10 plugin declarations, found ${pluginIds.length}`);
if (new Set(pluginIds).size !== pluginIds.length) throw new Error('duplicate plugin id');
console.log(`STATIC_CHECK=PASS plugins=${pluginIds.length} bytes=${Buffer.byteLength(html)}`);
