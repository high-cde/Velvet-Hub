# xCLOUD Enterprise v0.3 — Release notes

## Cosa cambia

Questa release sostituisce la landing minimale con una shell Enterprise Mission Control orientata a operations verificabili. Introduce navigazione per dieci superfici, registry dei moduli, stato esplicito del data plane, policy `default-deny`, collegamenti a ZDOS e War Room, layout responsive e controllo statico ripetibile.

## Moduli dichiarati

CRM & Accounts, Projects & Tasks, Documents, Inventory, Billing, Reports, Integrations, Audit & Evidence, Administration e Automations.

## Limiti dichiarati

La shell pubblica resta statica, mentre è stato aggiunto un foundation backend separato. Non contiene autenticazione server-side, database, persistenza multi-tenant, webhook, fatturazione reale, transazioni blockchain o scritture verso servizi esterni. Le superfici mostrano intenzionalmente `BACKEND REQUIRED` e non presentano dati sintetici come dati aziendali reali.

## Sicurezza

Il browser non contiene token, password, chiavi private o credenziali. Le integrazioni write-capable sono escluse dalla shell. Il file legacy resta nel repository di lavoro per confronto e rollback locale e non deve essere copiato nel webroot pubblico.

## Verifica

```text
STATIC_CHECK=PASS plugins=10
```

## Prossima tranche

La prossima release dovrà introdurre backend Node/Express, schema PostgreSQL, sessioni e ruoli, audit event append-only, import/export controllato e un bridge read-only verificato verso War Room/Evidence Core. Ogni integrazione esterna dovrà avere un contratto, timeout, retry, policy e test prima dell’attivazione.
