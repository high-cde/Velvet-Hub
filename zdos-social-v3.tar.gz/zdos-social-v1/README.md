# ZDOS Social Public Network v1

Servizio sociale pubblico separato da xCLOUD e War Room. Registrazione libera con handle pubblico, feed cronologico, canali pubblici, WebSocket per messaggi di canale, chat privata prevista dal modello dati, directory di link WhatsApp/Discord sottoposta a revisione e DOOM // Signal Room.

## Confini di sicurezza

Il piano Z-CYBERCORE è difensivo. Le categorie vengono valutate con livelli `allow`, `review`, `quarantine` e `block`; il sistema non esegue exploit, scansioni, brute force o attività contro terzi. I post e messaggi non vengono registrati nei log di processo. Gli allegati sono salvati in quarantena, limitati a MIME allowlist e 10 MB, con SHA-256 per la catena di custodia minima.

La registrazione non richiede email. L’email, se fornita, non viene mostrata pubblicamente. Non vengono raccolti dati di localizzazione, rubrica, contatti WhatsApp o Discord, né vengono effettuati scraping o sincronizzazioni di messaggi esterni. I link esterni sono pubblici, volontari e sottoposti a revisione.

La DOOM Room pubblica solo notizie con fonte e stato verificato. Non ospita ROM, BIOS, asset proprietari, malware o istruzioni per danneggiare sistemi. I claim su hardware quantistico sono pubblicabili solo con fonte tecnica primaria o istituzionale.

## Deploy

Il servizio usa `127.0.0.1:3030`, database dedicato `zdos_social` e directory `/var/lib/zdos-social`. Nginx espone il servizio sul dominio pubblico. Prima del deploy è obbligatorio creare backup di webroot, unità, env e database. Dopo l’installazione eseguire health locale e pubblico, test di registrazione con account reale dell’amministratore e scansione dei file pubblici.

## Stato v1

Il pacchetto contiene una base funzionante per account, feed, canali, messaggi realtime, report, directory link e allegati in quarantena. Per il lancio pubblico completo restano necessarie una pagina amministrativa autenticata per revisioni e ricorsi, retention policy verificata, backup PostgreSQL cifrato e rate-limit a livello Nginx o Redis. Non vengono creati utenti, canali, post o notizie fittizie.
