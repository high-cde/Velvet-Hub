/* ZDOS Social: Mission Control Sociale, public-by-default, privacy-minimal, Z-CYBERCORE defensive moderation. */
import express from 'express';
import http from 'node:http';
import crypto from 'node:crypto';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { WebSocketServer } from 'ws';
import multer from 'multer';
import bcrypt from 'bcryptjs';
import pg from 'pg';

const { Pool } = pg;
const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3030);
const PUBLIC_DIR = process.env.PUBLIC_DIR || path.resolve(__dirname, '../public');
const DATA_DIR = process.env.DATA_DIR || '/var/lib/zdos-social';
const UPLOAD_DIR = path.join(DATA_DIR, 'uploads');
fs.mkdirSync(UPLOAD_DIR, { recursive: true, mode: 0o750 });
const pool = new Pool({
  ...(process.env.DATABASE_URL ? { connectionString: process.env.DATABASE_URL } : {
    host: process.env.DB_HOST || '127.0.0.1',
    port: Number(process.env.DB_PORT || 5432),
    database: process.env.DB_NAME || 'zdos_social',
    user: process.env.DB_USER || 'zdos_social_app',
    password: process.env.DB_PASSWORD
  }),
  max: 10,
  idleTimeoutMillis: 30_000,
  connectionTimeoutMillis: 5_000
});
const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '64kb' }));
app.use(express.urlencoded({ extended: false, limit: '16kb' }));
app.use((req, res, next) => { res.setHeader('X-Content-Type-Options','nosniff'); res.setHeader('X-Frame-Options','SAMEORIGIN'); res.setHeader('Referrer-Policy','no-referrer'); res.setHeader('Permissions-Policy','camera=(), microphone=(), geolocation=()'); next(); });
app.use(express.static(PUBLIC_DIR, { etag: true, maxAge: '1h' }));

const randomId = (bytes=18) => crypto.randomBytes(bytes).toString('hex');
const digest = (v) => crypto.createHash('sha256').update(v).digest('hex');
const cleanHandle = (v) => String(v || '').trim().replace(/^@/, '').replace(/[^a-zA-Z0-9_.-]/g, '').slice(0, 32);
const validPublicUrl = (v) => { try { const u = new URL(v); return ['https:'].includes(u.protocol) && !['localhost','127.0.0.1','::1'].includes(u.hostname) && !/^10\.|^192\.168\.|^172\.(1[6-9]|2\d|3[01])\./.test(u.hostname); } catch { return false; } };

function moderateText(text) {
  const s = String(text || '').normalize('NFKC').replace(/\s+/g, ' ').trim();
  if (!s) return { state: 'block', reason: 'empty' };
  if (/(child sexual|sexual exploitation|csam)/i.test(s)) return { state: 'block', reason: 'sexual_exploitation' };
  if (/(build|make|assemble).{0,35}(bomb|explosive|weapon)/i.test(s) || /(detonate|attack).{0,35}(school|station|crowd)/i.test(s)) return { state: 'quarantine', reason: 'violent_operational_content' };
  if (/(kill yourself|go die|i will find you|death threat)/i.test(s)) return { state: 'quarantine', reason: 'credible_threat_signal' };
  if (/(dox|home address|phone number|private address|leak).{0,35}(name|address|number|photo)/i.test(s)) return { state: 'quarantine', reason: 'doxxing_signal' };
  if (/(porn|explicit sex|nude leak|sexual services)/i.test(s)) return { state: 'review', reason: 'sexual_or_obscene_content' };
  if (/(kill all|attack them|terrorist recruitment|join the jihad)/i.test(s)) return { state: 'review', reason: 'extremist_or_hateful_signal' };
  if (/(buy followers|free crypto|click my link).{0,50}(cash|money|followers)/i.test(s)) return { state: 'review', reason: 'spam_or_scam_signal' };
  return { state: 'allow', reason: null };
}

async function audit(actorId, action, targetType, targetId, outcome) { await pool.query('INSERT INTO zdos_social_audit(actor_id,action,target_type,target_id,outcome) VALUES($1,$2,$3,$4,$5)', [actorId || null, action, targetType || null, targetId || null, outcome]); }
async function sessionUser(req) { const raw = String(req.headers.authorization || '').replace(/^Bearer\s+/i,'').trim(); if (!raw) return null; const r = await pool.query('SELECT u.id,u.handle,u.role,u.status FROM zdos_social_sessions s JOIN zdos_social_users u ON u.id=s.user_id WHERE s.token_digest=$1 AND s.expires_at>now() AND u.status IN (\'active\',\'limited\')', [digest(raw)]); return r.rows[0] || null; }
async function requireUser(req,res,next) { try { req.user=await sessionUser(req); if (!req.user) return res.status(401).json({ error:'authentication_required' }); next(); } catch { res.status(503).json({ error:'auth_unavailable' }); } }

app.get('/api/health', async (_req,res) => { try { await pool.query('SELECT 1'); res.json({ schema:'zdos.social.health.v1', status:'ok', service:'zdos-social-public', version:'1.0.0', database:'connected', moderation:'z-cybercore-defensive' }); } catch { res.status(503).json({ schema:'zdos.social.health.v1', status:'degraded', database:'unavailable' }); } });
app.get('/api/public/config', (_req,res) => res.json({ schema:'zdos.social.public-config.v1', registration:'open', feed:'chronological', live_chat:true, uploads:{ allowed:['image/jpeg','image/png','image/webp','application/pdf','text/plain'], max_bytes:10_000_000 }, external_links:'public-opt-in', doom_room:'public-curated', sensitive_data:'not_collected_by_default' }));

app.post('/api/auth/register', async (req,res) => { const handle=cleanHandle(req.body?.handle); const password=String(req.body?.password || ''); const email=String(req.body?.email || '').trim().slice(0,254) || null; if (!/^[a-zA-Z0-9][a-zA-Z0-9_.-]{2,31}$/.test(handle) || password.length<12 || password.length>128) return res.status(400).json({ error:'handle_or_password_policy' }); const id=randomId(); const hash=await bcrypt.hash(password,12); try { await pool.query('INSERT INTO zdos_social_users(id,handle,email,password_hash) VALUES($1,$2,$3,$4)',[id,handle,email,hash]); const token=randomId(32); await pool.query('INSERT INTO zdos_social_sessions(id,user_id,token_digest,expires_at) VALUES($1,$2,$3,now()+interval \'30 days\')',[randomId(),id,digest(token)]); await audit(id,'register','profile',id,'allow'); res.status(201).json({ user:{id,handle,role:'member'}, token }); } catch(e) { if (e.code==='23505') return res.status(409).json({ error:'handle_or_email_taken' }); res.status(500).json({ error:'registration_failed' }); } });
app.post('/api/auth/login', async (req,res) => { const handle=cleanHandle(req.body?.handle); const password=String(req.body?.password || ''); const r=await pool.query('SELECT id,handle,role,status,password_hash FROM zdos_social_users WHERE handle_lower=lower($1)',[handle]); const u=r.rows[0]; if(!u || !(await bcrypt.compare(password,u.password_hash)) || !['active','limited'].includes(u.status)) return res.status(401).json({ error:'invalid_credentials' }); const token=randomId(32); await pool.query('INSERT INTO zdos_social_sessions(id,user_id,token_digest,expires_at) VALUES($1,$2,$3,now()+interval \'30 days\')',[randomId(),u.id,digest(token)]); await audit(u.id,'login','profile',u.id,'allow'); res.json({ user:{id:u.id,handle:u.handle,role:u.role}, token }); });
app.post('/api/auth/logout', requireUser, async (req,res) => { const raw=String(req.headers.authorization||'').replace(/^Bearer\s+/i,'').trim(); await pool.query('DELETE FROM zdos_social_sessions WHERE token_digest=$1',[digest(raw)]); await audit(req.user.id,'logout','profile',req.user.id,'allow'); res.status(204).end(); });

app.get('/api/feed', async (req,res) => { const limit=Math.min(Math.max(Number(req.query.limit||30),1),50); const r=await pool.query('SELECT p.id,p.body,p.created_at,u.handle FROM zdos_social_posts p JOIN zdos_social_users u ON u.id=p.author_id WHERE p.moderation_state=\'allow\' ORDER BY p.created_at DESC,p.id DESC LIMIT $1',[limit]); res.json({ schema:'zdos.social.feed.v1', mode:'chronological', posts:r.rows }); });
app.post('/api/posts', requireUser, async (req,res) => { const body=String(req.body?.body||'').trim(); if(body.length<1 || body.length>4000) return res.status(400).json({error:'body_length'}); const m=moderateText(body); if(m.state==='block') return res.status(422).json({error:'content_blocked',reason:m.reason}); const r=await pool.query('INSERT INTO zdos_social_posts(author_id,body,moderation_state,moderation_reason) VALUES($1,$2,$3,$4) RETURNING id,created_at',[req.user.id,body,m.state,m.reason]); await audit(req.user.id,'create_post','post',String(r.rows[0].id),m.state); res.status(m.state==='allow'?201:202).json({ id:r.rows[0].id, state:m.state, reason:m.reason, created_at:r.rows[0].created_at }); });
app.post('/api/posts/:id/report', requireUser, async (req,res) => { const categories=new Set(['harassment','obscenity','threat','doxxing','terrorism','spam','copyright','other']); const category=String(req.body?.category||'other'); if(!categories.has(category)) return res.status(400).json({error:'invalid_category'}); await pool.query('INSERT INTO zdos_social_reports(reporter_id,target_type,target_id,category,note) VALUES($1,\'post\',$2,$3,$4)',[req.user.id,String(req.params.id),category,String(req.body?.note||'').slice(0,1000)||null]); await audit(req.user.id,'report','post',String(req.params.id),'open'); res.status(201).json({status:'open'}); });

app.get('/api/channels', async (_req,res)=>{ const r=await pool.query('SELECT id,slug,name,description,visibility,created_at FROM zdos_social_channels WHERE visibility=\'public\' ORDER BY created_at ASC'); res.json({schema:'zdos.social.channels.v1',channels:r.rows}); });
app.post('/api/channels', requireUser, async (req,res)=>{ const name=String(req.body?.name||'').trim().slice(0,80); const description=String(req.body?.description||'').trim().slice(0,500); const slug=name.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'').slice(0,60); if(!slug||!description) return res.status(400).json({error:'channel_fields'}); const m=moderateText(name+' '+description); if(m.state!=='allow') return res.status(422).json({error:'channel_requires_review',state:m.state,reason:m.reason}); try { const r=await pool.query('INSERT INTO zdos_social_channels(id,slug,name,description,created_by) VALUES($1,$2,$3,$4,$5) RETURNING id,slug,name,description,visibility',[randomId(),slug,name,description,req.user.id]); await audit(req.user.id,'create_channel','channel',r.rows[0].id,'allow'); res.status(201).json(r.rows[0]); } catch(e){ res.status(e.code==='23505'?409:500).json({error:'channel_create_failed'}); } });
app.get('/api/channels/:id/messages', async(req,res)=>{ const r=await pool.query('SELECT m.id,m.body,m.created_at,u.handle FROM zdos_social_messages m JOIN zdos_social_users u ON u.id=m.sender_id WHERE m.channel_id=$1 AND m.moderation_state=\'allow\' ORDER BY m.created_at DESC,m.id DESC LIMIT 100',[req.params.id]); res.json({schema:'zdos.social.channel-messages.v1',messages:r.rows.reverse()}); });
app.post('/api/channels/:id/messages', requireUser, async(req,res)=>{ const body=String(req.body?.body||'').trim(); if(body.length<1||body.length>4000) return res.status(400).json({error:'body_length'}); const exists=await pool.query('SELECT 1 FROM zdos_social_channels WHERE id=$1 AND visibility=\'public\'',[req.params.id]); if(!exists.rowCount) return res.status(404).json({error:'channel_not_found'}); const m=moderateText(body); if(m.state==='block') return res.status(422).json({error:'content_blocked',reason:m.reason}); const r=await pool.query('INSERT INTO zdos_social_messages(channel_id,sender_id,body,moderation_state,moderation_reason) VALUES($1,$2,$3,$4,$5) RETURNING id,created_at',[req.params.id,req.user.id,body,m.state,m.reason]); await audit(req.user.id,'create_channel_message','message',String(r.rows[0].id),m.state); broadcast(req.params.id,{type:'message',id:r.rows[0].id,handle:req.user.handle,body:m.state==='allow'?body:'[in revisione]',created_at:r.rows[0].created_at}); res.status(m.state==='allow'?201:202).json({id:r.rows[0].id,state:m.state,reason:m.reason}); });

app.get('/api/social-links', async(_req,res)=>{ const r=await pool.query('SELECT id,platform,title,public_url,description,created_at FROM zdos_social_links WHERE moderation_state=\'published\' ORDER BY created_at DESC'); res.json({schema:'zdos.social.links.v1',links:r.rows}); });
app.post('/api/social-links', requireUser, async(req,res)=>{ const platform=String(req.body?.platform||''); const title=String(req.body?.title||'').trim().slice(0,100); const url=String(req.body?.public_url||'').trim(); const description=String(req.body?.description||'').trim().slice(0,500); if(!['discord','whatsapp','github','website'].includes(platform)||!title||!validPublicUrl(url)) return res.status(400).json({error:'public_link_policy'}); const r=await pool.query('INSERT INTO zdos_social_links(owner_id,platform,title,public_url,description) VALUES($1,$2,$3,$4,$5) RETURNING id,moderation_state',[req.user.id,platform,title,url,description]); await audit(req.user.id,'submit_public_link','link',String(r.rows[0].id),'review'); res.status(202).json({id:r.rows[0].id,state:r.rows[0].moderation_state}); });
app.get('/api/doom/news', async(_req,res)=>{ const r=await pool.query('SELECT id,title,summary,source_url,source_name,published_at FROM zdos_social_doom_news WHERE state=\'verified\' ORDER BY published_at DESC NULLS LAST,id DESC LIMIT 50'); res.json({schema:'zdos.social.doom-news.v1',policy:'verified-public-sources-only',news:r.rows}); });

const upload=multer({ storage:multer.diskStorage({ destination:(_req,_file,cb)=>cb(null,UPLOAD_DIR), filename:(_req,file,cb)=>cb(null,randomId()+'-'+path.basename(file.originalname).replace(/[^a-zA-Z0-9._-]/g,'_').slice(-80)) }), limits:{fileSize:10_000_000,files:1}, fileFilter:(_req,file,cb)=>cb(null,['image/jpeg','image/png','image/webp','application/pdf','text/plain'].includes(file.mimetype)) });
app.post('/api/attachments', requireUser, (req,res)=>upload.single('file')(req,res,async(err)=>{ if(err||!req.file) return res.status(400).json({error:'attachment_rejected'}); const hash=await new Promise((resolve,reject)=>{const h=crypto.createHash('sha256');const s=fs.createReadStream(req.file.path);s.on('data',d=>h.update(d));s.on('end',()=>resolve(h.digest('hex')));s.on('error',reject)}); await audit(req.user.id,'upload_attachment','attachment',hash,'quarantine'); res.status(202).json({state:'quarantine',sha256:hash,filename:req.file.originalname,mime:req.file.mimetype,size:req.file.size,message:'Attachment queued for safety review'}); }));

const server=http.createServer(app); const wss=new WebSocketServer({server,path:'/ws'}); const rooms=new Map(); function broadcast(room,data){ for(const ws of rooms.get(room)||[]) if(ws.readyState===1) ws.send(JSON.stringify(data)); } wss.on('connection',(ws,req)=>{ const room=new URL(req.url,'http://local').searchParams.get('channel'); if(!room){ws.close(1008,'channel_required');return} if(!rooms.has(room)) rooms.set(room,new Set()); rooms.get(room).add(ws); ws.send(JSON.stringify({type:'presence',mode:'public-channel',channel:room})); ws.on('close',()=>{rooms.get(room)?.delete(ws);if(!rooms.get(room)?.size)rooms.delete(room)}); });
app.get('/social.html', (_req,res)=>res.sendFile(path.join(PUBLIC_DIR,'social.html')));
app.get('/console/:area', (req,res)=>{
  if (!['zlang','xdr','nodes'].includes(req.params.area)) return res.status(404).send('console_not_found');
  res.sendFile(path.join(PUBLIC_DIR,'console.html'));
});
app.get('*',(req,res,next)=>{ if(req.path.startsWith('/api/')||req.path.startsWith('/ws')) return next(); res.sendFile(path.join(PUBLIC_DIR,'index.html')); });
server.listen(PORT,'127.0.0.1',()=>console.log(JSON.stringify({service:'zdos-social-public',host:'127.0.0.1',port:PORT,version:'1.0.0'})));
