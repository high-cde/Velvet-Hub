BEGIN;

CREATE TABLE IF NOT EXISTS zdos_social_users (
  id TEXT PRIMARY KEY,
  handle TEXT NOT NULL,
  handle_lower TEXT GENERATED ALWAYS AS (lower(handle)) STORED,
  email TEXT,
  password_hash TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','moderator','admin')),
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','limited','suspended','deleted')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE UNIQUE INDEX IF NOT EXISTS zdos_social_users_handle_idx ON zdos_social_users(handle_lower);
CREATE UNIQUE INDEX IF NOT EXISTS zdos_social_users_email_idx ON zdos_social_users(lower(email)) WHERE email IS NOT NULL;

CREATE TABLE IF NOT EXISTS zdos_social_sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  token_digest CHAR(64) NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_sessions_user_idx ON zdos_social_sessions(user_id, expires_at DESC);

CREATE TABLE IF NOT EXISTS zdos_social_posts (
  id BIGSERIAL PRIMARY KEY,
  author_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  body TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 4000),
  reply_to BIGINT REFERENCES zdos_social_posts(id) ON DELETE SET NULL,
  repost_of BIGINT REFERENCES zdos_social_posts(id) ON DELETE SET NULL,
  moderation_state TEXT NOT NULL DEFAULT 'allow' CHECK (moderation_state IN ('allow','review','quarantine','block')),
  moderation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_posts_feed_idx ON zdos_social_posts(created_at DESC, id DESC) WHERE moderation_state='allow';
CREATE INDEX IF NOT EXISTS zdos_social_posts_author_idx ON zdos_social_posts(author_id, created_at DESC);
CREATE INDEX IF NOT EXISTS zdos_social_posts_reply_idx ON zdos_social_posts(reply_to, created_at DESC);

CREATE TABLE IF NOT EXISTS zdos_social_reactions (
  post_id BIGINT NOT NULL REFERENCES zdos_social_posts(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  reaction TEXT NOT NULL CHECK (reaction IN ('like','support','signal')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(post_id,user_id,reaction)
);
CREATE INDEX IF NOT EXISTS zdos_social_reactions_post_idx ON zdos_social_reactions(post_id, reaction);

CREATE TABLE IF NOT EXISTS zdos_social_channels (
  id TEXT PRIMARY KEY,
  slug TEXT NOT NULL UNIQUE,
  name TEXT NOT NULL,
  description TEXT NOT NULL,
  visibility TEXT NOT NULL DEFAULT 'public' CHECK (visibility IN ('public','private')),
  created_by TEXT REFERENCES zdos_social_users(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_channels_visibility_idx ON zdos_social_channels(visibility, created_at DESC);

CREATE TABLE IF NOT EXISTS zdos_social_channel_members (
  channel_id TEXT NOT NULL REFERENCES zdos_social_channels(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('member','moderator','owner')),
  joined_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  PRIMARY KEY(channel_id,user_id)
);
CREATE INDEX IF NOT EXISTS zdos_social_channel_members_user_idx ON zdos_social_channel_members(user_id, joined_at DESC);

CREATE TABLE IF NOT EXISTS zdos_social_messages (
  id BIGSERIAL PRIMARY KEY,
  channel_id TEXT REFERENCES zdos_social_channels(id) ON DELETE CASCADE,
  sender_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  recipient_id TEXT REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  body TEXT NOT NULL CHECK (char_length(body) BETWEEN 1 AND 4000),
  moderation_state TEXT NOT NULL DEFAULT 'allow' CHECK (moderation_state IN ('allow','review','quarantine','block')),
  moderation_reason TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CHECK ((channel_id IS NOT NULL) <> (recipient_id IS NOT NULL))
);
CREATE INDEX IF NOT EXISTS zdos_social_messages_channel_idx ON zdos_social_messages(channel_id, created_at DESC, id DESC);
CREATE INDEX IF NOT EXISTS zdos_social_messages_dm_idx ON zdos_social_messages(sender_id, recipient_id, created_at DESC, id DESC);

CREATE TABLE IF NOT EXISTS zdos_social_reports (
  id BIGSERIAL PRIMARY KEY,
  reporter_id TEXT NOT NULL REFERENCES zdos_social_users(id) ON DELETE CASCADE,
  target_type TEXT NOT NULL CHECK (target_type IN ('post','message','profile','link','attachment')),
  target_id TEXT NOT NULL,
  category TEXT NOT NULL CHECK (category IN ('harassment','obscenity','threat','doxxing','terrorism','spam','copyright','other')),
  note TEXT,
  state TEXT NOT NULL DEFAULT 'open' CHECK (state IN ('open','reviewing','resolved','dismissed')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_reports_queue_idx ON zdos_social_reports(state, created_at ASC);
CREATE INDEX IF NOT EXISTS zdos_social_reports_target_idx ON zdos_social_reports(target_type, target_id, created_at DESC);

CREATE TABLE IF NOT EXISTS zdos_social_links (
  id BIGSERIAL PRIMARY KEY,
  owner_id TEXT REFERENCES zdos_social_users(id) ON DELETE SET NULL,
  platform TEXT NOT NULL CHECK (platform IN ('discord','whatsapp','github','website')),
  title TEXT NOT NULL,
  public_url TEXT NOT NULL,
  description TEXT NOT NULL DEFAULT '',
  moderation_state TEXT NOT NULL DEFAULT 'review' CHECK (moderation_state IN ('review','published','blocked')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_links_public_idx ON zdos_social_links(platform, created_at DESC) WHERE moderation_state='published';

CREATE TABLE IF NOT EXISTS zdos_social_doom_news (
  id BIGSERIAL PRIMARY KEY,
  title TEXT NOT NULL,
  summary TEXT NOT NULL,
  source_url TEXT NOT NULL,
  source_name TEXT NOT NULL,
  published_at TIMESTAMPTZ,
  state TEXT NOT NULL DEFAULT 'pending' CHECK (state IN ('pending','verified','rejected')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_doom_news_feed_idx ON zdos_social_doom_news(published_at DESC, id DESC) WHERE state='verified';

CREATE TABLE IF NOT EXISTS zdos_social_audit (
  id BIGSERIAL PRIMARY KEY,
  actor_id TEXT REFERENCES zdos_social_users(id) ON DELETE SET NULL,
  action TEXT NOT NULL,
  target_type TEXT,
  target_id TEXT,
  outcome TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS zdos_social_audit_recent_idx ON zdos_social_audit(created_at DESC);

REVOKE ALL ON TABLE zdos_social_users, zdos_social_sessions, zdos_social_posts, zdos_social_reactions, zdos_social_channels, zdos_social_channel_members, zdos_social_messages, zdos_social_reports, zdos_social_links, zdos_social_doom_news, zdos_social_audit FROM PUBLIC;
COMMIT;
